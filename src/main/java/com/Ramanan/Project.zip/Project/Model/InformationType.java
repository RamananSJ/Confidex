package com.Ramanan.Project.Model;


public enum InformationType {
    PUBLIC, CONFIDENTIAL
}
