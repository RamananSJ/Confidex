package com.Ramanan.Project.Model;


public enum RequestStatus {
    PENDING, APPROVED, REJECTED
}

