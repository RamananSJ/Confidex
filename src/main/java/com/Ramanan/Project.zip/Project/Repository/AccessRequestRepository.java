package com.Ramanan.Project.Repository;

import com.Ramanan.Project.Model.AccessRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccessRequestRepository extends JpaRepository<AccessRequest, Long> {
}

